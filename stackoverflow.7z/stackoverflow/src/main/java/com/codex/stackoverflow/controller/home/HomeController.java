package com.codex.stackoverflow.controller.home;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codex.stackoverflow.entity.home.AnswerDTO;
import com.codex.stackoverflow.entity.home.QuestionDTO;
import com.codex.stackoverflow.service.home.HomeSvc;

@RestController
@RequestMapping("/home")
public class HomeController {

	private static final Logger LOGGER = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	private HomeSvc homeSvc;

	@GetMapping(path = "/courses")
	public List<String> getAllCourses() {
		try {
			LOGGER.debug("Entering courses method of home controller");
			List<String> courses = homeSvc.findAllCourses();
			return courses;

		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}

	@PostMapping(path = "/questions")
	public List<String> getAllQuestions(@RequestBody Integer userId) {
		try {
			LOGGER.debug("Entering getAllQuestions method of home controller");
			List<String> questions = homeSvc.findAllQuestions(userId);
			return questions;
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}

	@PostMapping(path = "/questionPosted")
	public Boolean postQuestions(@RequestBody QuestionDTO dtoToSave) {
		try {
			LOGGER.debug("Entering postQuestions method of home controller");
			QuestionDTO dto = homeSvc.validate(dtoToSave);
			if (dto != null) {
				return true;
			}
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return false;
	}
	
	@PostMapping(path = "/answerPost")
	public Boolean postAnswer(@RequestBody AnswerDTO dtoToSave) {
		try {
			LOGGER.debug("Entering postQuestions method of home controller");
			AnswerDTO dto = homeSvc.validateAnswer(dtoToSave);
			if (dto != null) {
				return true;
			}
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return false;
	}
	
	@PostMapping(path = "/getAnswers")
	public List<AnswerDTO> getAnswers(@RequestBody Integer questionId) {
		try {
			LOGGER.debug("Entering getAnswers method of home controller");
			List<AnswerDTO> dtoList = homeSvc.getAnswer(questionId);
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");	
		}
		return null;
	}
}
