package com.codex.stackoverflow.entity.home;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

public class QuestionDTO implements Serializable {
	
	private Integer questionId;
	private String questionDesc;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(referencedColumnName = "courseId")
	private CourseDTO  courseDTO;
	private LocalDate questionDate;
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "question")
	private List<AnswerDTO> answerDTO;
	@Override
	public String toString() {
		return "QuestionDTO [questionId=" + questionId + ", questionDesc=" + questionDesc + ", courseDTO=" + courseDTO
				+ ", questionDate=" + questionDate + ", answerDTO=" + answerDTO + "]";
	}
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public String getQuestionDesc() {
		return questionDesc;
	}
	public void setQuestionDesc(String questionDesc) {
		this.questionDesc = questionDesc;
	}
	public CourseDTO getCourseDTO() {
		return courseDTO;
	}
	public void setCourseDTO(CourseDTO courseDTO) {
		this.courseDTO = courseDTO;
	}
	public LocalDate getQuestionDate() {
		return questionDate;
	}
	public void setQuestionDate(LocalDate questionDate) {
		this.questionDate = questionDate;
	}
	public List<AnswerDTO> getAnswerDTO() {
		return answerDTO;
	}
	public void setAnswerDTO(List<AnswerDTO> answerDTO) {
		this.answerDTO = answerDTO;
	}
	
	

}
