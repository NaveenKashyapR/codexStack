package com.codex.stackoverflow.service.home;

import java.util.List;

import com.codex.stackoverflow.entity.home.AnswerDTO;
import com.codex.stackoverflow.entity.home.QuestionDTO;

public interface HomeSvc {

	List<String> findAllCourses();

	List<String> findAllQuestions(Integer userId);

	QuestionDTO validate(QuestionDTO dtoToSave);

	AnswerDTO validateAnswer(AnswerDTO dtoToSave);

	List<AnswerDTO> getAnswer(Integer questionId);

}
