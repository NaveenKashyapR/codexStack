package com.codex.stackoverflow.repository.home;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.codex.stackoverflow.entity.home.AnswerDTO;

public interface AnswerRepository extends CrudRepository<AnswerDTO, Integer> {

	List<AnswerDTO> findAllByQuestion(Integer questionId);

}
