package com.codex.stackoverflow.entity.home;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

import com.codex.stackoverflow.entity.registration.RegistrationDTO;

@Entity
public class CourseDTO implements Serializable {

	private Integer courseId;
	private String courseName;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(referencedColumnName = "registrationId")
	private RegistrationDTO regDto;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "courseDTO")
	private List<QuestionDTO> questionDesc;

	@Override
	public String toString() {
		return "CourseDTO [courseId=" + courseId + ", courseName=" + courseName + ", regDto=" + regDto
				+ ", questionDesc=" + questionDesc + "]";
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public RegistrationDTO getRegDto() {
		return regDto;
	}

	public void setRegDto(RegistrationDTO regDto) {
		this.regDto = regDto;
	}

	public List<QuestionDTO> getQuestionDesc() {
		return questionDesc;
	}

	public void setQuestionDesc(List<QuestionDTO> questionDesc) {
		this.questionDesc = questionDesc;
	}

}
