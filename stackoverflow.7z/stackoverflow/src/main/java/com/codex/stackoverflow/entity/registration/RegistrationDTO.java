package com.codex.stackoverflow.entity.registration;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenericGenerator;

import com.codex.stackoverflow.entity.home.CourseDTO;

@Entity
public class RegistrationDTO implements Serializable {

	@Id
	@GenericGenerator(name = "id", strategy = "increment")
	@GeneratedValue(generator = "id")
	private Integer registrationId;
	private String userName;
	private String password;
	@OneToMany(cascade =CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "regDto")
	private List<CourseDTO> courses;

	public Integer getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(Integer registrationId) {
		this.registrationId = registrationId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "RegistrationDTO [registrationId=" + registrationId + ", userName=" + userName + ", password=" + password
				+ ", courses=" + courses + "]";
	}

	public List<CourseDTO> getCourses() {
		return courses;
	}

	public void setCourses(List<CourseDTO> courses) {
		this.courses = courses;
	}

}
