package com.codex.stackoverflow.repository.home;

import org.springframework.data.repository.CrudRepository;

import com.codex.stackoverflow.entity.home.CourseDTO;

public interface HomeRepository extends CrudRepository<CourseDTO, Integer> {

	CourseDTO findByCourseName(String courseName);
}
