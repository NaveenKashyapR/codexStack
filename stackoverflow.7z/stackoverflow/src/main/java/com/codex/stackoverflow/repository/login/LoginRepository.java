package com.codex.stackoverflow.repository.login;

import org.springframework.data.repository.CrudRepository;

import com.codex.stackoverflow.entity.registration.RegistrationDTO;

public interface LoginRepository extends CrudRepository<RegistrationDTO, Integer> {
	Boolean isMatched();

	RegistrationDTO findByUserNameAndPassword(String userName, String password);

	RegistrationDTO findByPassword(String password);

}
