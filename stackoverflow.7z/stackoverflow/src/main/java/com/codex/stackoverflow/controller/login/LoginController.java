package com.codex.stackoverflow.controller.login;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.codex.stackoverflow.entity.login.ChangePasswordDTO;
import com.codex.stackoverflow.entity.login.LoginDTO;
import com.codex.stackoverflow.entity.registration.RegistrationDTO;
import com.codex.stackoverflow.service.login.LoginService;

@RestController
public class LoginController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);
     
	@Autowired
	private LoginService service;

	@GetMapping(path = "/userLogin")
	public String userLogin(@RequestBody LoginDTO dtoToValidate) {

		LOGGER.debug("Entering userLogin method in controller");
		try {
			RegistrationDTO dtoAfterValidate = service.validateUser(dtoToValidate);
			if (dtoAfterValidate != null) {
				LOGGER.debug("Valid user");
				return "/courses";
			}
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}

	@PostMapping(path = "/changePassword")
	public ResponseEntity<RegistrationDTO> changePassword(@RequestBody ChangePasswordDTO dtoToChange) {
		LOGGER.debug("Entering changePassword method");
		try {
			RegistrationDTO dtoAfterChange = service.checkPassword(dtoToChange);
			if (dtoAfterChange != null) {
				LOGGER.debug("Password changed successfully");
				return new ResponseEntity<RegistrationDTO>(dtoAfterChange, HttpStatus.OK);
			}
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}
}
