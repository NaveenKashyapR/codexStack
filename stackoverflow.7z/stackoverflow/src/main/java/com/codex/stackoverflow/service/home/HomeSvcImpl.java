package com.codex.stackoverflow.service.home;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.codex.stackoverflow.entity.home.AnswerDTO;
import com.codex.stackoverflow.entity.home.CourseDTO;
import com.codex.stackoverflow.entity.home.QuestionDTO;
import com.codex.stackoverflow.repository.home.AnswerRepository;
import com.codex.stackoverflow.repository.home.HomeRepository;
import com.codex.stackoverflow.repository.home.QuestionRepository;

@Service
public class HomeSvcImpl implements HomeSvc {

	private Logger LOGGER = LoggerFactory.getLogger(HomeSvcImpl.class);

	@Autowired
	private HomeRepository repository;

	@Autowired
	private QuestionRepository questionRepository;

	@Autowired
	private AnswerRepository answerRepository;

	@Override
	public List<String> findAllCourses() {
		LOGGER.debug("Entering find all courses method in Service");
		try {
			List<CourseDTO> courseList = (List<CourseDTO>) repository.findAll();
			List<String> courses = new ArrayList<String>();
			for (CourseDTO dto : courseList) {
				courses.add(dto.getCourseName());
			}
			return courses;
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}

	@Override
	public List<String> findAllQuestions( Integer userId ) {
		List<String> courses = null ;
		List<Integer> coursesList = new ArrayList<Integer>();
		List<String> questions = new ArrayList<String>();
		LOGGER.debug("Entering findAllQuestions method in Service");
		try {
			for (int i = 0; i < courses.size(); i++) {
				CourseDTO courseDTO = new CourseDTO();
				List<QuestionDTO> questionList = new ArrayList<QuestionDTO>();
				courseDTO = repository.findByCourseName(courses.get(i));
				coursesList.add(courseDTO.getCourseId());
				questionList = questionRepository.findByCourseDTO(coursesList.get(i));
				for (QuestionDTO questionDTO : questionList) {
					questions.add(questionDTO.getQuestionDesc());
				}
			}
			return questions;
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}

	@Override
	public QuestionDTO validate(QuestionDTO dtoToSave) {
		try {
			LOGGER.debug("Entering validate method");
			dtoToSave.setQuestionDate(LocalDate.now());
			QuestionDTO dtoAfterSave = questionRepository.save(dtoToSave);
			if (dtoAfterSave != null) {
				return dtoAfterSave;
			}
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}

	@Override
	public AnswerDTO validateAnswer(AnswerDTO dtoToSave) {
		try {
			LOGGER.debug("Entering validate method");
			dtoToSave.setAnswerDate(LocalDate.now());
			AnswerDTO dtoAfterSave = answerRepository.save(dtoToSave);
			if (dtoAfterSave != null) {
				return dtoAfterSave;
			}
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}

	@Override
	public List<AnswerDTO> getAnswer(Integer questionId) {
		try {
			LOGGER.debug("Entering getAnswer method");
			if(Objects.nonNull(questionId)) {
				return answerRepository.findAllByQuestion(questionId);
			}
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}

}
