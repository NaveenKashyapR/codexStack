package com.codex.stackoverflow.service.login;

import com.codex.stackoverflow.entity.login.ChangePasswordDTO;
import com.codex.stackoverflow.entity.login.LoginDTO;
import com.codex.stackoverflow.entity.registration.RegistrationDTO;

public interface LoginService {

	RegistrationDTO validateUser(LoginDTO dtoToValidate);

	RegistrationDTO checkPassword(ChangePasswordDTO dtoToChange);
	

}
