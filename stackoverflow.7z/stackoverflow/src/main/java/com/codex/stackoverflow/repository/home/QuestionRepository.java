package com.codex.stackoverflow.repository.home;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.codex.stackoverflow.entity.home.QuestionDTO;

public interface QuestionRepository extends CrudRepository<QuestionDTO, Integer> {

	List<QuestionDTO> findByCourseDTO(Integer courseId);
}
