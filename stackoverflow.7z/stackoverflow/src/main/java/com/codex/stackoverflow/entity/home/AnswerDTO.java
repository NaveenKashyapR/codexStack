package com.codex.stackoverflow.entity.home;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
public class AnswerDTO implements Serializable {
	
	private Integer answerId;
	private String answerdesc;
	private LocalDate answerDate;
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn(referencedColumnName = "questionId")
	private QuestionDTO question;
	@Override
	public String toString() {
		return "AnswerDTO [answerId=" + answerId + ", answerdesc=" + answerdesc + ", answerDate=" + answerDate
				+ ", question=" + question + "]";
	}
	public Integer getAnswerId() {
		return answerId;
	}
	public void setAnswerId(Integer answerId) {
		this.answerId = answerId;
	}
	public String getAnswerdesc() {
		return answerdesc;
	}
	public void setAnswerdesc(String answerdesc) {
		this.answerdesc = answerdesc;
	}
	public LocalDate getAnswerDate() {
		return answerDate;
	}
	public void setAnswerDate(LocalDate answerDate) {
		this.answerDate = answerDate;
	}
	public QuestionDTO getQuestion() {
		return question;
	}
	public void setQuestion(QuestionDTO question) {
		this.question = question;
	}
	
	

}
