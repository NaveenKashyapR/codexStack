package com.codex.stackoverflow.service.login;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.codex.stackoverflow.controller.login.LoginController;
import com.codex.stackoverflow.entity.login.ChangePasswordDTO;
import com.codex.stackoverflow.entity.login.LoginDTO;
import com.codex.stackoverflow.entity.registration.RegistrationDTO;
import com.codex.stackoverflow.repository.login.LoginRepository;

@Service
public class LoginServiceImpl implements LoginService {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private LoginRepository repository;

	@Override
	public RegistrationDTO validateUser(LoginDTO dtoToValidate) {
		LOGGER.debug("Entering validateUser in Loginservice");
		try {
			if (!StringUtils.isEmpty(dtoToValidate.getUserName())
					&& !StringUtils.isEmpty(dtoToValidate.getPassword())) {
				LOGGER.debug("String validation completed");
				RegistrationDTO dto= repository.findByUserNameAndPassword(dtoToValidate.getUserName(),
						dtoToValidate.getPassword());
				if (dto != null) {
					return dto;
				}
			}
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");
		}
		return null;
	}

	@Override
	public RegistrationDTO checkPassword(ChangePasswordDTO dtoToChange) {
		LOGGER.debug("Entering checkPassword in Loginservice");
		try {
			if (!StringUtils.isEmpty(dtoToChange.getOldPassword()) && !StringUtils.isEmpty(dtoToChange.getNewPassword())
					&& !StringUtils.isEmpty(dtoToChange.getConfirmPassword())) {
				LOGGER.debug("All values are entered");
				if(dtoToChange.getNewPassword().equals(dtoToChange.getConfirmPassword())) {
					 RegistrationDTO dtoFound= repository.findByPassword(dtoToChange.getOldPassword());
					dtoFound.setPassword(dtoToChange.getConfirmPassword());
					return repository.save(dtoFound);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Sorry unable to process due to some exception");	
		}
		return null;
	}

}
